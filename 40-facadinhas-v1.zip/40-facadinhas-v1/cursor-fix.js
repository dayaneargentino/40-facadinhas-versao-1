// Script para forçar o cursor personalizado
document.addEventListener('DOMContentLoaded', function() {
    // Força o cursor personalizado em todos os elementos
    const style = document.createElement('style');
    style.textContent = `
        * {
            cursor: url('./assets/cursor.png') 16 16, url('assets/cursor.png') 16 16, pointer !important;
        }
        body {
            cursor: url('./assets/cursor.png') 16 16, url('assets/cursor.png') 16 16, pointer !important;
        }
    `;
    document.head.appendChild(style);
    
    // Também aplica via JavaScript
    document.body.style.cursor = "url('./assets/cursor.png') 16 16, url('assets/cursor.png') 16 16, pointer";
    
    // Aplica a todos os elementos
    const allElements = document.querySelectorAll('*');
    allElements.forEach(element => {
        element.style.cursor = "url('./assets/cursor.png') 16 16, url('assets/cursor.png') 16 16, pointer";
    });
}); 

// Lista dos caminhos dos sons
const clickSounds = [
  'assets/faca 1.mp3',
  'assets/faca 2.mp3',
  'assets/faca 3.mp3',
  'assets/faca 4.mp3',
  'assets/faca 5.mp3'
];
let soundIndex = 0;

// Função para tocar o som
function playClickSound() {
  const audio = new Audio(clickSounds[soundIndex]);
  audio.volume = 0.08;  
  audio.play();
  soundIndex = (soundIndex + 1) % clickSounds.length;
}

// Adiciona o evento global de clique
document.addEventListener('click', function(e) {
  if (window.mouseSoundOn !== false) {
    playClickSound();
  }
}); 