// Variáveis globais
let clickCount = 0;
const totalElements = 40;

// Array de elementos configuráveis
const elements = [
    { type: 'text', content: 'Cabeça', position: { x: '10%', y: '15%' } },
    { type: 'text', content: 'Pescoço', position: { x: '85%', y: '20%' } },
    { type: 'text', content: 'Ombros', position: { x: '20%', y: '25%' } },
    { type: 'text', content: 'Braços', position: { x: '75%', y: '30%' } },
    { type: 'text', content: 'Antebraços', position: { x: '80%', y: '40%' } },
    { type: 'text', content: 'Mãos', position: { x: '70%', y: '50%' } },
    { type: 'text', content: 'Dedos', position: { x: '30%', y: '55%' } },
    { type: 'text', content: 'Coração', position: { x: '95%', y: '55%' } },
    { type: 'text', content: 'Pulmões', position: { x: '5%', y: '50%' } },
    { type: 'text', content: 'Lóbulos superior direito', position: { x: '60%', y: '20%' } },
    { type: 'text', content: 'Lobos superior esquerdo', position: { x: '40%', y: '25%' } },
    { type: 'text', content: 'Traqueia', position: { x: '55%', y: '30%' } },
    { type: 'text', content: 'Esôfago', position: { x: '45%', y: '35%' } },
    { type: 'text', content: 'Laringe', position: { x: '65%', y: '40%' } },
    { type: 'text', content: 'Faringe', position: { x: '35%', y: '45%' } },
    { type: 'text', content: 'Cérebro', position: { x: '82%', y: '15%' } },
    { type: 'text', content: 'Telencéfalo', position: { x: '22%', y: '18%' } },
    { type: 'text', content: 'Diencéfalo', position: { x: '78%', y: '22%' } },
    { type: 'text', content: 'Tronco encefálico', position: { x: '28%', y: '28%' } },
    { type: 'text', content: 'Cerebelo', position: { x: '72%', y: '32%' } },
    { type: 'text', content: 'Esterno', position: { x: '32%', y: '12%' } },
    { type: 'text', content: 'Manúbrio', position: { x: '68%', y: '38%' } },
    { type: 'text', content: 'Costelas superiores', position: { x: '62%', y: '48%' } },
    { type: 'text', content: 'Clavículas', position: { x: '58%', y: '58%' } },
    { type: 'text', content: 'Vértebras cervicais', position: { x: '48%', y: '62%' } },
    { type: 'text', content: 'Ossos do crânio', position: { x: '15%', y: '35%' } },
    { type: 'text', content: 'Frontal', position: { x: '80%', y: '10%' } },
    { type: 'text', content: 'Parietais', position: { x: '20%', y: '10%' } },
    { type: 'text', content: 'Temporais', position: { x: '85%', y: '30%' } },
    { type: 'text', content: 'Occipital', position: { x: '10%', y: '30%' } },
    { type: 'text', content: 'Esfenoide', position: { x: '90%', y: '40%' } },
    { type: 'text', content: 'Etmoide', position: { x: '10%', y: '40%' } },
    { type: 'text', content: 'Mandíbula', position: { x: '80%', y: '50%' } },
    { type: 'text', content: 'Maxilares', position: { x: '20%', y: '50%' } },
    { type: 'text', content: 'Peitoral maior', position: { x: '70%', y: '60%' } },
    { type: 'text', content: 'Peitoral menor', position: { x: '30%', y: '60%' } }
];

// Definir área central bloqueada
const minX = 0.30, maxX = 0.70, minY = 0.30, maxY = 0.70;
const fontSize = 24;
const boxPadding = 8;

// Gerar 7 posições aleatórias para cada uma das 6 regiões, fora da área central
let regionPositions = [[], [], [], [], [], []]; // 0: sup-esq, 1: sup-dir, 2: inf-esq, 3: inf-dir, 4: acima, 5: abaixo
function generateRegionPositions() {
    regionPositions = [[], [], [], [], [], []];
    const attemptsMax = 100;
    const width = window.innerWidth;
    const height = window.innerHeight;
    const margin = 50; // Margem de segurança para evitar cortes
    
    // Definir área dos botões superiores direitos
    const btnRight = width * 0.75; // últimos 25% da largura
    const btnTop = 0; // topo
    const btnBottom = height * 0.15; // primeiros 15% da altura
    let allBoxes = [];
    // Lista de todos os termos reais (com quebras de linha)
    const allTerms = elements.map(e => e.content.split(' '));
    let termIdx = 0;
    for (let region = 0; region < 6; region++) {
        let count = 0;
        let tries = 0;
        while (count < 7 && tries < attemptsMax * 10 && termIdx < allTerms.length) {
            let posX, posY;
            if (region === 0) { // sup-esq
                posX = (margin + Math.random() * (minX * width - margin * 2)) / width;
                posY = (margin + Math.random() * (minY * height - margin * 2)) / height;
            } else if (region === 1) { // sup-dir
                posX = (maxX * width + margin + Math.random() * (width - maxX * width - margin * 2)) / width;
                posY = (margin + Math.random() * (minY * height - margin * 2)) / height;
            } else if (region === 2) { // inf-esq
                posX = (margin + Math.random() * (minX * width - margin * 2)) / width;
                posY = (maxY * height + margin + Math.random() * (height - maxY * height - margin * 2)) / height;
            } else if (region === 3) { // inf-dir
                posX = (maxX * width + margin + Math.random() * (width - maxX * width - margin * 2)) / width;
                posY = (maxY * height + margin + Math.random() * (height - maxY * height - margin * 2)) / height;
            } else if (region === 4) { // acima da imagem
                posX = (minX * width + margin + Math.random() * (maxX * width - minX * width - margin * 2)) / width;
                posY = (margin + Math.random() * (minY * height - margin * 2)) / height;
            } else { // abaixo da imagem
                posX = (minX * width + margin + Math.random() * (maxX * width - minX * width - margin * 2)) / width;
                posY = (maxY * height + margin + Math.random() * (height - maxY * height - margin * 2)) / height;
            }
            
            // Garantir que as posições estejam dentro dos limites válidos
            posX = Math.max(margin / width, Math.min(1 - margin / width, posX));
            posY = Math.max(margin / height, Math.min(1 - margin / height, posY));
            
            // Medir largura real da linha mais longa e altura real do termo
            const lines = allTerms[termIdx];
            const maxLine = lines.reduce((a, b) => a.length > b.length ? a : b, '');
            const { width: estWidth } = measureTextWidth(maxLine, fontSize);
            const estHeight = fontSize * lines.length;
            const leftPx = posX * width;
            const topPx = posY * height;
            const box = {
                left: leftPx - estWidth / 2 - boxPadding,
                right: leftPx + estWidth / 2 + boxPadding,
                top: topPx - estHeight / 2 - boxPadding,
                bottom: topPx + estHeight / 2 + boxPadding
            };
            
            // Verifica se invade área central
            const centralLeft = minX * width;
            const centralRight = maxX * width;
            const centralTop = minY * height;
            const centralBottom = maxY * height;
            const invadeCentral = !(box.right < centralLeft || box.left > centralRight || box.bottom < centralTop || box.top > centralBottom);
            
            // Verifica se invade área dos botões superiores direitos
            const invadeBtns = (box.left < width && box.right > btnRight && box.top < btnBottom && box.bottom > btnTop);
            
            // Verifica se está muito próximo das bordas
            const tooCloseToEdge = box.left < margin || box.right > width - margin || box.top < margin || box.bottom > height - margin;
            
            // Verifica se sobrepõe qualquer outra posição já usada (todas regiões)
            const tooClose = allBoxes.some(b =>
                !(box.right < b.left || box.left > b.right || box.bottom < b.top || box.top > b.bottom)
            );
            
            if (!invadeCentral && !invadeBtns && !tooCloseToEdge && !tooClose) {
                regionPositions[region].push(box);
                allBoxes.push(box);
                count++;
                termIdx++;
            }
            tries++;
        }
        // Se não conseguiu preencher todas as posições, avança o termo para não travar
        while (count < 7 && termIdx < allTerms.length) {
            termIdx++;
            count++;
        }
    }
}

// Gerar posições ao carregar e ao redimensionar
window.addEventListener('DOMContentLoaded', generateRegionPositions);
window.addEventListener('resize', generateRegionPositions);

// Array para guardar as caixas ocupadas pelas palavras
let usedBoxes = [];

// Captura referências
const clickButton = document.getElementById('clickButton');
const counterText = document.getElementById('counterText');
const elementsContainer = document.getElementById('elementsContainer');

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Garantir que apenas a página 1 esteja ativa no início
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById('page1').classList.add('active');
    
    setupEventListeners();
});

// Configurar event listeners
function setupEventListeners() {
    clickButton.addEventListener('click', handleClick);
}

// Manipular clique no botão
function handleClick() {
    // Incrementa contador
    clickCount++;
    counterText.textContent = clickCount;

    // Criar X vermelho na metade superior da imagem
    createRedX();

    // Mostra o próximo elemento
    if (clickCount <= totalElements) {
        const elConfig = elements[clickCount - 1];
        
        // Cria o elemento baseado no tipo
        let el;
        if (elConfig.type === 'text') {
            el = document.createElement('div');
            // Quebra de linha para termos compostos
            const lines = elConfig.content.split(' ');
            el.innerHTML = lines.join('<br>');
            el.className = 'element';
            // Fonte fixa
            // Alterna as 6 regiões a cada termo
            const idx = clickCount - 1;
            const region = idx % 6; // alterna entre 0,1,2,3,4,5
            const posIdx = Math.floor(idx / 6); // avança a posição em cada região
            // Pega a posição pré-calculada
            const box = regionPositions[region][posIdx];
            // Se não houver posição (por algum motivo), sorteia fallback
            let posX = 0.05, posY = 0.05;
            if (box) {
                posX = (box.left + box.right) / 2 / window.innerWidth;
                posY = (box.top + box.bottom) / 2 / window.innerHeight;
            }
            // Garante que não haja sobreposição com outros termos já exibidos
            const tooClose = usedBoxes.some(b =>
                !(box.right < b.left || box.left > b.right || box.bottom < b.top || box.top > b.bottom)
            );
            if (!tooClose) {
                // Calcular margens de segurança para evitar cortes
                const margin = 20; // margem em pixels
                const maxLeft = window.innerWidth - box.right - margin;
                const maxTop = window.innerHeight - box.bottom - margin;
                
                // Ajustar posição se necessário para manter dentro dos limites
                let adjustedPosX = posX;
                let adjustedPosY = posY;
                
                if (box.left < margin) {
                    adjustedPosX = (margin + box.right / 2) / window.innerWidth;
                } else if (box.right > window.innerWidth - margin) {
                    adjustedPosX = (window.innerWidth - margin - box.right / 2) / window.innerWidth;
                }
                
                if (box.top < margin) {
                    adjustedPosY = (margin + box.bottom / 2) / window.innerHeight;
                } else if (box.bottom > window.innerHeight - margin) {
                    adjustedPosY = (window.innerHeight - margin - box.bottom / 2) / window.innerHeight;
                }
                
                Object.assign(el.style, {
                    color: '#FF0000',
                    fontFamily: 'Courier New, monospace',
                    fontWeight: 'bold',
                    position: 'absolute',
                    left: (adjustedPosX * 100) + '%',
                    top: (adjustedPosY * 100) + '%',
                    opacity: '0',
                    fontSize: fontSize + 'px',
                    textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
                    transition: 'opacity 0.5s ease',
                    lineHeight: '1.1',
                    textAlign: 'center',
                    transform: 'translate(-50%, -50%)', // Centralizar o elemento
                    whiteSpace: 'nowrap', // Evitar quebra de linha indesejada
                    overflow: 'visible' // Permitir que o texto seja visível mesmo se ultrapassar
                });
                usedBoxes.push(box);
            } else {
                el.style.display = 'none';
            }
        } else if (elConfig.type === 'image') {
            el = document.createElement('img');
            el.src = elConfig.src;
            Object.assign(el.style, {
                position: 'absolute',
                left: elConfig.position.x,
                top: elConfig.position.y,
                opacity: '0',
                transition: 'opacity 0.5s ease'
            });
        }
        
        // Adiciona o elemento ao container
        if (el) {
            elementsContainer.appendChild(el);
            // Animação fade-in
            setTimeout(() => el.style.opacity = '1', 50);
        }
    }

    // Transição de página
    if (clickCount >= totalElements) {
        // Exibir faixa "Facadinhas" sobre a imagem central
        showFacadinhasBanner();
        setTimeout(() => {
            navigateToMovementPage();
        }, 5000); // 5 segundos
    }
}

// Função para criar X vermelho permanente na imagem
function createRedX() {
    const bodyShape = document.getElementById('bodyShape');
    const rect = bodyShape.getBoundingClientRect();
    
    // Calcular posição baseada no número do clique
    // Distribuir os X em uma grade 8x5 na área da imagem
    const gridCols = 8;
    const gridRows = 5;
    const currentIndex = clickCount - 1;
    
    const col = currentIndex % gridCols;
    const row = Math.floor(currentIndex / gridCols);
    
    // Calcular posição relativa na imagem
    const relativeX = (col + 0.5) / gridCols; // 0.5 para centralizar na célula
    const relativeY = (row + 0.5) / gridRows; // 0.5 para centralizar na célula
    
    // Converter para posição absoluta na tela
    const x = rect.left + rect.width * relativeX;
    const y = rect.top + rect.height * relativeY;
    
    // Criar o X
    const redX = document.createElement('div');
    redX.innerHTML = '✗';
    redX.id = `redX-${clickCount}`;
    Object.assign(redX.style, {
        position: 'fixed',
        left: x + 'px',
        top: y + 'px',
        transform: 'translate(-50%, -50%)',
        color: '#FF0000',
        fontSize: '20px',
        fontWeight: 'bold',
        textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
        zIndex: '1000',
        pointerEvents: 'none',
        opacity: '0',
        transition: 'opacity 0.5s ease'
    });
    
    document.body.appendChild(redX);
    
    // Animação de aparecimento
    setTimeout(() => {
        redX.style.opacity = '1';
    }, 10);
    
    // O X permanece na tela (não é removido)
}

// Função para medir a largura real da palavra com determinado font-size
function measureTextWidth(text, fontSize) {
    const temp = document.createElement('span');
    temp.style.position = 'absolute';
    temp.style.visibility = 'hidden';
    temp.style.fontSize = fontSize + 'px';
    temp.style.fontFamily = 'Courier New, monospace';
    temp.style.fontWeight = 'bold';
    temp.textContent = text;
    document.body.appendChild(temp);
    const width = temp.offsetWidth;
    const height = temp.offsetHeight;
    document.body.removeChild(temp);
    return { width, height };
}

// Função para exibir a faixa "Facadinhas"
function showFacadinhasBanner() {
    // Remove banner anterior se existir
    const oldBanner = document.getElementById('facadinhas-banner');
    if (oldBanner) oldBanner.remove();
    // Cria o banner
    const banner = document.createElement('div');
    banner.id = 'facadinhas-banner';
    banner.textContent = '40 facadas e contando...';
    Object.assign(banner.style, {
        position: 'fixed',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        background: '#FF0000',
        color: '#FFF',
        fontFamily: 'Courier New, monospace',
        fontWeight: 'bold',
        fontSize: '3em',
        width: '100vw',
        height: '80px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: '32px',
        boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
        zIndex: '3000',
        textAlign: 'center',
        letterSpacing: '0.1em',
        opacity: '0',
        transition: 'opacity 0.3s',
    });
    document.body.appendChild(banner);
    setTimeout(() => {
        banner.style.opacity = '1';
    }, 10);
}

// Navegar para a página de movimento
function navigateToMovementPage() {
    // Transição de fade antes de avançar
    const fadeOverlay = document.getElementById('fade-overlay');
    if (fadeOverlay) {
        fadeOverlay.classList.add('active');
        setTimeout(() => {
            window.location.href = '1 - movement-page.html';
        }, 1300);
    } else {
        window.location.href = '1 - movement-page.html';
    }
}

// Navegar para a página de notícias
function navigateToNewsPage() {
    const fadeOverlay = document.getElementById('fade-overlay');
    if (fadeOverlay) {
        fadeOverlay.classList.add('active');
        setTimeout(() => {
            window.location.href = '2 - news-page.html';
        }, 1300);
    } else {
        window.location.href = '2 - news-page.html';
    }
}

// Navegar para a camada de poemas
function navigateToPoemLayer() {
    // Redirecionar para a página de poemas
    window.location.href = '3 - poem-layer.html';
}

// Reiniciar o jogo
function restartGame() {
    clickCount = 0;
    counterText.textContent = '0';
    elementsContainer.innerHTML = '';
    usedBoxes = [];
    generateRegionPositions();
    // Remover todos os X vermelhos
    for (let i = 1; i <= 40; i++) {
        const redX = document.getElementById(`redX-${i}`);
        if (redX) {
            redX.remove();
        }
    }
}

// Efeito de partículas no clique
function createParticle(x, y) {
    const particle = document.createElement('div');
    particle.style.position = 'absolute';
    particle.style.left = x + 'px';
    particle.style.top = y + 'px';
    particle.style.width = '4px';
    particle.style.height = '4px';
    particle.style.backgroundColor = '#FF0000';
    particle.style.borderRadius = '50%';
    particle.style.pointerEvents = 'none';
    particle.style.zIndex = '1000';
    
    document.body.appendChild(particle);
    
    // Animação da partícula
    const angle = Math.random() * Math.PI * 2;
    const velocity = Math.random() * 5 + 2;
    const vx = Math.cos(angle) * velocity;
    const vy = Math.sin(angle) * velocity;
    
    let opacity = 1;
    const animate = () => {
        if (opacity <= 0) {
            document.body.removeChild(particle);
            return;
        }
        
        const currentX = parseFloat(particle.style.left);
        const currentY = parseFloat(particle.style.top);
        
        particle.style.left = (currentX + vx) + 'px';
        particle.style.top = (currentY + vy) + 'px';
        particle.style.opacity = opacity;
        
        opacity -= 0.02;
        requestAnimationFrame(animate);
    };
    
    animate();
}

// Adicionar efeito de partículas ao clique
document.addEventListener('click', function(e) {
    if (e.target.closest('#clickButton')) {
        for (let i = 0; i < 8; i++) {
            createParticle(e.clientX, e.clientY);
        }
    }
}); 