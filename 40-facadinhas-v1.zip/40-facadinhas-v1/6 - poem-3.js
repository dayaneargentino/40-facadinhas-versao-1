// Função para voltar à página principal
function goBack() {
    window.location.href = '3 - poem-layer.html';
}

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    console.log('Poema 3 carregado');
    
    // Adicionar efeito de partículas ao clicar no botão voltar
    const backButton = document.querySelector('.back-button');
    if (backButton) {
        backButton.addEventListener('click', function(e) {
            for (let i = 0; i < 6; i++) {
                createParticle(e.clientX, e.clientY);
            }
        });
    }
    
    // Efeito da imagem assustadora
    const shockImage = document.querySelector('.shock-image');
    const shockContainer = document.querySelector('.shock-image-container');
    console.log('Imagem encontrada:', shockImage);
    
    if (shockImage && shockContainer) {
        console.log('Configurando efeito da imagem...');
        
        // Mostrar a imagem após 8 segundos (quando o texto chegar nela)
        setTimeout(() => {
            console.log('Mostrando imagem...');
            
            // Adicionar flash na tela
            shockContainer.classList.add('flash');
            
            // Mostrar a imagem
            shockImage.classList.add('show');
            
            // Efeito de choque após aparecer
            setTimeout(() => {
                console.log('Aplicando efeito de choque...');
                shockImage.classList.add('shock');
                
                // Som de choque (se disponível)
                try {
                    const shockSound = new Audio('assets/shock.mp3');
                    shockSound.volume = 0.1;
                    shockSound.play().catch(() => {});
                } catch (e) {
                    console.log('Som de choque não disponível');
                }
                
                // Remover classe de choque após a animação
                setTimeout(() => {
                    shockImage.classList.remove('shock');
                }, 800);
                
                // Remover flash após a animação
                setTimeout(() => {
                    shockContainer.classList.remove('flash');
                }, 800);
            }, 800);
        }, 8000); // 8 segundos para chegar no meio do poema
    } else {
        console.error('Imagem ou container não encontrado!');
    }
});

// Efeitos de partículas
function createParticle(x, y) {
    const particle = document.createElement('div');
    particle.style.position = 'fixed';
    particle.style.left = x + 'px';
    particle.style.top = y + 'px';
    particle.style.width = '4px';
    particle.style.height = '4px';
    particle.style.backgroundColor = '#FF0000';
    particle.style.borderRadius = '50%';
    particle.style.pointerEvents = 'none';
    particle.style.zIndex = '1000';
    
    document.body.appendChild(particle);
    
    // Animação da partícula
    const angle = Math.random() * Math.PI * 2;
    const velocity = Math.random() * 4 + 2;
    const vx = Math.cos(angle) * velocity;
    const vy = Math.sin(angle) * velocity;
    
    let opacity = 1;
    let scale = 1;
    
    const animate = () => {
        if (opacity <= 0) {
            document.body.removeChild(particle);
            return;
        }
        
        opacity -= 0.03;
        scale -= 0.02;
        
        particle.style.left = (parseFloat(particle.style.left) + vx) + 'px';
        particle.style.top = (parseFloat(particle.style.top) + vy) + 'px';
        particle.style.opacity = opacity;
        particle.style.transform = `scale(${scale})`;
        
        requestAnimationFrame(animate);
    };
    
    animate();
} 