// Configurações da camada de poemas
const poemConfig = {
    animationDuration: 1200,
    titleDelay: 500
};

// Elementos DOM
const restartButton = document.getElementById('restartButton');
const poemButtons = document.querySelectorAll('.poem-button');

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializePoemLayer();
    setupEventListeners();
});

// Inicializar a camada de poemas
function initializePoemLayer() {
    console.log('Camada de poemas inicializada');
}

// Configurar event listeners
function setupEventListeners() {
    // Efeitos de partículas para o botão de reinício
    restartButton.addEventListener('click', function(e) {
        for (let i = 0; i < 6; i++) {
            createPoemParticle(e.clientX, e.clientY);
        }
    });
    
    // Efeitos de partículas para os botões dos poemas
    poemButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            for (let i = 0; i < 8; i++) {
                createPoemParticle(e.clientX, e.clientY);
            }
        });
    });
}

// Função para abrir poemas específicos
function openPoem(poemNumber) {
    const poemFiles = {
        1: 'poem-1.html',
        2: 'poem-2.html', 
        3: 'poem-3.html'
    };
    
    const fileName = poemFiles[poemNumber];
    if (fileName) {
        window.location.href = fileName;
    }
}

// Reiniciar a camada de poemas
function restartPoemLayer() {
    // Navegar para a página 5
    window.location.href = 'page5.html';
}

// Efeitos de partículas para os botões
function createPoemParticle(x, y) {
    const particle = document.createElement('div');
    particle.style.position = 'fixed';
    particle.style.left = x + 'px';
    particle.style.top = y + 'px';
    particle.style.width = '4px';
    particle.style.height = '4px';
    particle.style.backgroundColor = '#FF0000';
    particle.style.borderRadius = '50%';
    particle.style.pointerEvents = 'none';
    particle.style.zIndex = '1000';
    
    document.body.appendChild(particle);
    
    // Animação da partícula
    const angle = Math.random() * Math.PI * 2;
    const velocity = Math.random() * 4 + 2;
    const vx = Math.cos(angle) * velocity;
    const vy = Math.sin(angle) * velocity;
    
    let opacity = 1;
    let scale = 1;
    
    const animate = () => {
        if (opacity <= 0) {
            document.body.removeChild(particle);
            return;
        }
        
        opacity -= 0.03;
        scale -= 0.02;
        
        particle.style.left = (parseFloat(particle.style.left) + vx) + 'px';
        particle.style.top = (parseFloat(particle.style.top) + vy) + 'px';
        particle.style.opacity = opacity;
        particle.style.transform = `scale(${scale})`;
        
        requestAnimationFrame(animate);
    };
    
    animate();
}

// Função para abrir a camada de poemas (mantida para compatibilidade)
function openPoemLayer() {
    window.open('poem-layer.html', '_blank', 'width=1200,height=800');
} 