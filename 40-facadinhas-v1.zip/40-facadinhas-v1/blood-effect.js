// Função para criar mancha de sangue
function createBloodStain(x, y) {
    const bloodStain = document.createElement('div');
    bloodStain.className = 'blood-stain';
    
    // Posicionar a mancha no local do clique
    bloodStain.style.left = (x - 10) + 'px';
    bloodStain.style.top = (y - 10) + 'px';
    
    // Adicionar variações aleatórias
    const variations = ['small', 'large', 'irregular'];
    const randomVariation = variations[Math.floor(Math.random() * variations.length)];
    bloodStain.classList.add(randomVariation);
    
    // Adicionar ao body
    document.body.appendChild(bloodStain);
    
    // Remover após a animação
    setTimeout(() => {
        if (bloodStain.parentNode) {
            bloodStain.parentNode.removeChild(bloodStain);
        }
    }, 2000);
}

// Adicionar listener de clique global
document.addEventListener('click', function(e) {
    // Evitar criar mancha em elementos específicos (botões, links, etc.)
    const target = e.target;
    const isInteractive = target.tagName === 'BUTTON' || 
                         target.tagName === 'A' || 
                         target.closest('button') || 
                         target.closest('a');
    
    if (!isInteractive) {
        createBloodStain(e.clientX, e.clientY);
    }
});

// Adicionar listener de toque para dispositivos móveis
document.addEventListener('touchstart', function(e) {
    const touch = e.touches[0];
    const target = e.target;
    const isInteractive = target.tagName === 'BUTTON' || 
                         target.tagName === 'A' || 
                         target.closest('button') || 
                         target.closest('a');
    
    if (!isInteractive) {
        createBloodStain(touch.clientX, touch.clientY);
    }
}); 