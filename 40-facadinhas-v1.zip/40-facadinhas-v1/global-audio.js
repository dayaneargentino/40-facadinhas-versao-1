// Sistema de áudio global para transições suaves entre páginas
class GlobalAudioManager {
    constructor() {
        this.bgAudio = null;
        this.mouseSoundOn = true;
        this.bgSoundOn = true;
        this.cursorSounds = [
            'assets/faca 1.mp3',
            'assets/faca 2.mp3',
            'assets/faca 3.mp3',
            'assets/faca 4.mp3',
            'assets/faca 5.mp3'
        ];
        this.cursorSoundIdx = 0;
        this.init();
    }

    init() {
        // Recuperar estado salvo
        this.mouseSoundOn = (localStorage.getItem('mouseSoundOn') === null) ? true : (localStorage.getItem('mouseSoundOn') === 'true');
        this.bgSoundOn = (localStorage.getItem('bgSoundOn') === null) ? true : (localStorage.getItem('bgSoundOn') === 'true');
        
        // Inicializar áudio de fundo
        this.initBgAudio();
        
        // Salvar estado antes de sair da página
        window.addEventListener('beforeunload', () => {
            if (this.bgAudio) {
                localStorage.setItem('bgAudioTime', this.bgAudio.currentTime);
                localStorage.setItem('bgSoundOn', this.bgSoundOn);
            }
            localStorage.setItem('mouseSoundOn', this.mouseSoundOn);
        });

        // Inicializar controles de áudio se existirem
        this.initAudioControls();
        
        // Inicializar som do cursor
        this.initCursorSound();
    }

    initBgAudio() {
        // Verificar se já existe uma instância global
        if (window.globalBgAudio) {
            this.bgAudio = window.globalBgAudio;
        } else {
            this.bgAudio = new Audio('assets/trilha.mp3');
            this.bgAudio.loop = true;
            this.bgAudio.volume = 0.08;
            
            // Recuperar tempo salvo
            const savedTime = localStorage.getItem('bgAudioTime');
            if (savedTime) {
                this.bgAudio.currentTime = parseFloat(savedTime);
            }
            
            // Tornar global
            window.globalBgAudio = this.bgAudio;
        }

        // Iniciar se estiver ativado
        if (this.bgSoundOn && !window.location.pathname.endsWith('index.html')) {
            this.bgAudio.play().catch(() => {});
        }
    }

    initAudioControls() {
        const toggleMouseBtn = document.getElementById('toggleMouseSound');
        const toggleBgBtn = document.getElementById('toggleBgSound');

        if (toggleMouseBtn) {
            this.updateMouseBtnVisual(toggleMouseBtn);
            toggleMouseBtn.addEventListener('click', () => {
                this.mouseSoundOn = !this.mouseSoundOn;
                localStorage.setItem('mouseSoundOn', this.mouseSoundOn);
                this.updateMouseBtnVisual(toggleMouseBtn);
            });
        }

        if (toggleBgBtn) {
            this.updateBgBtnVisual(toggleBgBtn);
            toggleBgBtn.addEventListener('click', () => {
                this.bgSoundOn = !this.bgSoundOn;
                localStorage.setItem('bgSoundOn', this.bgSoundOn);
                this.updateBgBtnVisual(toggleBgBtn);
                if (this.bgSoundOn) {
                    this.bgAudio.play().catch(() => {});
                } else {
                    this.bgAudio.pause();
                }
            });
        }
    }

    updateMouseBtnVisual(btn) {
        btn.textContent = this.mouseSoundOn ? '🔊 cursor' : '🔇 cursor';
        if (this.mouseSoundOn) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    }

    updateBgBtnVisual(btn) {
        btn.textContent = this.bgSoundOn ? '🔊 trilha' : '🔈 trilha';
        if (this.bgSoundOn) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    }

    initCursorSound() {
        document.addEventListener('click', (e) => {
            const target = e.target;
            const isInteractive = target.tagName === 'BUTTON' || 
                                 target.tagName === 'A' || 
                                 target.closest('button') || 
                                 target.closest('a');
            
            if (!isInteractive && this.mouseSoundOn) {
                this.playCursorSound();
            }
        });
    }

    playCursorSound() {
        const audio = new Audio(this.cursorSounds[this.cursorSoundIdx]);
        audio.volume = 0.08;
        audio.play().catch(() => {});
        this.cursorSoundIdx = (this.cursorSoundIdx + 1) % this.cursorSounds.length;
    }

    // Método para iniciar áudio na primeira interação (para index.html)
    startOnFirstClick() {
        if (this.bgSoundOn && !this.bgAudio.playing) {
            this.bgAudio.play().catch(() => {});
        }
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    window.audioManager = new GlobalAudioManager();
});

// Para páginas que precisam iniciar na primeira interação
function startAudioOnFirstClick() {
    if (window.audioManager) {
        window.audioManager.startOnFirstClick();
    }
} 